package com.terrapay.demoproject.LibraryManagementSystem.service;

import com.terrapay.demoproject.LibraryManagementSystem.model.Issue;
import com.terrapay.demoproject.LibraryManagementSystem.model.TextBooks;

import java.util.List;



public interface IssueService

{


    public Issue saveIssuedBooks(Issue issue);


    public List<Issue> fetchIssuedBooksList();

    public Issue fetchIssuedBooksById(Long issueId);


    public List<Issue> fetchIssuedBooksByName(String issuedTo);


    public List<Issue> fetchIssuedBooksByTitle(String issuedBooks);

    public void deleteBookByIssueId(Long issueId);



    public Issue updateIssueBooks(Long issueId, Issue issue);
}
