package com.terrapay.demoproject.LibraryManagementSystem.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;
import java.util.Date;
import java.util.List;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long issueId;


    @Column(name = "issue_date")
    private Date issueDate;



    @Column(name = "expected_return_date")
    private Date expectedReturnDate;


    private String returned;

    @ManyToOne
    @JoinColumn(name = "issuedTo")
    private Member issuedTo;

    @ManyToOne
    @JoinColumn(name= "issuedBooks")
    private TextBooks issuedBooks;






        }


