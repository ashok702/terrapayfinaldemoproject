package com.terrapay.demoproject.LibraryManagementSystem.service;

import com.terrapay.demoproject.LibraryManagementSystem.model.Issue;
import com.terrapay.demoproject.LibraryManagementSystem.model.TextBooks;
import com.terrapay.demoproject.LibraryManagementSystem.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;


@Service
public class IssueServiceImpl implements IssueService

{


    @Autowired
    private IssueRepository issueRepository;


    @Override
    public Issue saveIssuedBooks(Issue issue)

    {

        return issueRepository.save(issue);


    }

    @Override
    public List<Issue> fetchIssuedBooksList() {
        return issueRepository.findAll();
    }

    @Override
    public Issue fetchIssuedBooksById(Long issueId) {
        return issueRepository.findById(issueId).get();
    }

    @Override
    public List<Issue> fetchIssuedBooksByName(String issuedTo) {
        return issueRepository.findByIssuedTo(issuedTo);
    }

    @Override
    public List<Issue> fetchIssuedBooksByTitle(String issuedBooks) {
        return issueRepository.findByissuedBooks(issuedBooks);
    }

    @Override
    public void deleteBookByIssueId(Long issueId) {
        issueRepository.deleteById(issueId);

    }





    @Override
    public Issue updateIssueBooks(Long issueId, Issue issue)

    {

       Issue issueDB=issueRepository.findById(issueId).get();

        if(Objects.nonNull(issue.getExpectedReturnDate())  && !"".equalsIgnoreCase(String.valueOf(issue.getExpectedReturnDate())))

        {

            issueDB.setExpectedReturnDate(issue.getExpectedReturnDate());


        }


        if(Objects.nonNull(issue.getReturned())  && !"".equalsIgnoreCase(issue.getReturned()))

        {

            issueDB.setReturned(issue.getReturned());
        }


        if(Objects.nonNull(issue.getIssuedTo())  && !"".equalsIgnoreCase(String.valueOf(issue.getIssuedTo())))

        {

            issueDB.setIssuedTo(issue.getIssuedTo());
        }

        if(Objects.nonNull(issue.getIssuedBooks())  && !"".equalsIgnoreCase(String.valueOf(issue.getIssuedBooks())))

        {

            issueDB.setIssuedBooks(issue.getIssuedBooks());
        }
        return issueRepository.save(issueDB);
    }


}












