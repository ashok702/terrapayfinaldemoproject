package com.terrapay.demoproject.LibraryManagementSystem.controller;


import com.terrapay.demoproject.LibraryManagementSystem.model.Issue;
import com.terrapay.demoproject.LibraryManagementSystem.service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
public class IssueController

{

    @Autowired
    private IssueService issueService;


    @PostMapping("/issuedBooks")
    public ResponseEntity<String> saveIssuedBooks(@RequestBody Issue issue)
    {
        Issue issue1 = issueService.saveIssuedBooks(issue);
        if(issue1 != null){
            return ResponseEntity.created(URI.create("")).body("Book issue successfully");
        }
        return ResponseEntity.ok("Error while issuing the book");
    }



    @GetMapping("/issuedBooks")
    public List<Issue> fetchIssuedBooksList()

    {

        return issueService.fetchIssuedBooksList();

    }


    @GetMapping("/issuedBooks/{id}")
    public Issue fetchIssuedBooksById(@PathVariable("id") Long issueId)

    {

        return issueService.fetchIssuedBooksById(issueId);

    }



    @GetMapping("/issuedBooks/issuedTo/{issuedTo}")
    public List<Issue> fetchIssuedBooksByName(@PathVariable("issuedTo") String issuedTo)

    {

       return issueService.fetchIssuedBooksByName(issuedTo);

    }

    @GetMapping("/issuedBooks/issuedBooks/{issuedBooks}")
    public List<Issue> fetchIssuedBooksByTitle(@PathVariable("issuedBooks") String issuedBooks)

    {

        return issueService.fetchIssuedBooksByTitle(issuedBooks);

    }


    @DeleteMapping("/issuedBooks/{issueId}")
    public String deleteBookByIssueId(@PathVariable("issueId") Long issueId)

    {

        issueService.deleteBookByIssueId(issueId);

        return "BOOK deleted successfully";
    }


    @PutMapping("/issuedBooks/{issueId}")
    public Issue updateIssueBooks(@PathVariable("issueId") Long issueId, @RequestBody Issue issue)

    {

        return issueService.updateIssueBooks(issueId,issue);


    }











}
