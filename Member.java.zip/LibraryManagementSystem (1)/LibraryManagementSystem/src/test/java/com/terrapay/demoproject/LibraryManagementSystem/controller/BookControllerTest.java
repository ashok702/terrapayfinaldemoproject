package com.terrapay.demoproject.LibraryManagementSystem.controller;

import com.terrapay.demoproject.LibraryManagementSystem.error.TextBookNotFoundException;
import com.terrapay.demoproject.LibraryManagementSystem.model.TextBooks;
import com.terrapay.demoproject.LibraryManagementSystem.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(BookController.class)
class BookControllerTest {

    @MockBean
    private BookService bookService;

    @Autowired
    private MockMvc mockMvc;

    private TextBooks textBooks;

    @BeforeEach
    void setUp() {

        textBooks = TextBooks.builder()
                .title("CONTROL SYSTEMS")
                .authors("KYO OGATTA & VAN VALKENBERG")
                .quantity(75L)
                .price(250L)
                .textbooksId(2L)
                .build();

    }



    @Test
    void saveBook() throws Exception {

        TextBooks inputTextBooks = TextBooks.builder()
                .title("CONTROL SYSTEMS")
                .authors("KYO OGATTA & VAN VALKENBERG")
                .quantity(75L)
                .price(250L)
                .build();

        Mockito.when(bookService.saveBook(inputTextBooks)).thenReturn(textBooks);

        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"title\":\"CONTROL SYSTEMS\",\n" +
                        "    \"authors\":\"KYO OGATTA & VAN VALKENBERG\",\n" +
                        "     \"quantity\":75,\n" +
                        "     \"price\":250\n" +
                        "\n" +
                        "}")).andExpect(status().isOk());



    }

    @Test
    void fetchTextBooksById() throws Exception {

        Mockito.when(bookService.fetchTextBooksById(1L))
                .thenReturn(Optional.ofNullable(textBooks));

        mockMvc.perform(get("/books/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value(textBooks.getTitle()));







    }

}