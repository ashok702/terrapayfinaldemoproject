package com.terrapay.demoproject.LibraryManagementSystem.service;

import com.terrapay.demoproject.LibraryManagementSystem.model.TextBooks;
import com.terrapay.demoproject.LibraryManagementSystem.repository.BookRepository;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest
class BookServiceTest

{

    @Autowired
    private BookService bookService;

    @MockBean
    private BookRepository bookRepository;

    @BeforeEach
    void setUp()

    {

        TextBooks textBooks=TextBooks.builder()
                .title("ELECTRICAL MACHINES")
                .authors("PS BIMBRA & CHAND")
                .quantity(35L)
                .price(800L)
                .build();

        Mockito.when(bookRepository.findBytitle("ELECTRICAL MACHINES")).thenReturn(textBooks);

    }


    @Test
    @DisplayName("Get Data based on valid textbooks name")

    public void whenValidTextBooksName_thenDepartmentShouldFound()

    {

        String title="ELECTRICAL MACHINES";

        TextBooks found=bookService.fetchTextBooksByName(title);

        assertEquals(title,found.getTitle());



    }

}