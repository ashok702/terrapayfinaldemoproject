package com.terrapay.demoproject.LibraryManagementSystem.repository;

import com.terrapay.demoproject.LibraryManagementSystem.model.TextBooks;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.junit.jupiter.api.Assertions.*;


@DataJpaTest
class BookRepositoryTest

{

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private TestEntityManager entityManager;

    @BeforeEach
    void setUp()

    {

        TextBooks textBooks = TextBooks.builder()
                .title("POWER SYSTEMS")
                .authors("VK MEHTA & ROHIT MEHTA")
                .quantity(15L)
                .price(450L)
                .build();

        entityManager.persist(textBooks);



    }



    @Test
    public void whenFindById_thenReturnTexBooks()

    {

        TextBooks textBooks = bookRepository.findById(1L).get();

        assertEquals(textBooks.getTitle(),"POWER SYSTEMS");

    }
}